module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}", // Scan all JavaScript, JSX, TypeScript, and TSX files
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};