
const Dashboard = () => {
    return (
        <div>
            <h1>Welcome, you have successfully logged in</h1>
        </div>
    )
}

export default Dashboard;